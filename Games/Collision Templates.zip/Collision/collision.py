import pygame, sys, time, random
from pygame.locals import *

WINDOWWIDTH = 600
WINDOWHEIGHT = 500
WHITE = (255,255,255)

pygame.init()
mainClock = pygame.time.Clock()
applauseSound = pygame.mixer.Sound('applause.wav')  #set up applause Sound

# set up the window
windowSurface = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT), 0, 32)
pygame.display.set_caption('Simple Collision Example--ESC to Quit')

# set up the block data structure
stampRect = pygame.Rect(50, 50,90, 60)
stampImage = pygame.image.load('stamp.png')
stampStretchedImage = pygame.transform.scale(stampImage, (90, 60))
ramRect= pygame.Rect(300, 250, 70, 60)
ramImage = pygame.image.load('ram.png')
ramStretchedImage = pygame.transform.scale(ramImage, (70, 60))

pygame.mouse.set_pos(stampRect.centerx, stampRect.centery)  # place mouse at Stampie's location

# play the game
while True:
    for event in pygame.event.get():
        if event.type==QUIT:
            pygame.quit()
            sys.exit()
        if event.type==KEYUP:
            if event.key==K_ESCAPE:
                pygame.quit()
                sys.exit()
        # move Stampie to follow the mouse cursor
        if event.type == MOUSEMOTION:      
                stampRect.move_ip(event.pos[0]-stampRect.centerx, event.pos[1]-stampRect.centery)

    windowSurface.fill(WHITE)
 
    windowSurface.blit(ramStretchedImage,ramRect)
    windowSurface.blit(stampStretchedImage,stampRect)
    
    if stampRect.colliderect(ramRect):  #Stampie collides with Ram
        applauseSound.play()
        ramRect.top = random.randint(0,WINDOWHEIGHT- ramRect.height)
        ramRect.left = random.randint(0,WINDOWWIDTH- ramRect.width)
      
                                   
    pygame.display.update()
    mainClock.tick(40)
